const BASE_URL = 'http://26.84.9.17:5000/api';

export default BASE_URL;