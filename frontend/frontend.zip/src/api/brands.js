import { apiGet } from "."

export const getBrands = () => apiGet('/products/brands');