import { apiGet } from ".";

export const getOrderHistory = () => apiGet('/products/new-arrivals');