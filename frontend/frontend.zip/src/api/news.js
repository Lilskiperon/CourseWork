import { apiGet } from ".";

export const getNews = () => apiGet('/news');
